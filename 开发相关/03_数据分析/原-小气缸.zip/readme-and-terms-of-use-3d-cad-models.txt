
EN   Your CAD data on 27.08.2025 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 1384807 DSBC-100-80-PPVA-N3 
    
    DWG2D, 1384807 DSBC-100-80-PPVA-N3---(0), 1384807_DSBC-100-80-PPVA-N3_front.dwg
    DWG2D, 1384807 DSBC-100-80-PPVA-N3---(0), 1384807_DSBC-100-80-PPVA-N3_back.dwg
    DWG2D, 1384807 DSBC-100-80-PPVA-N3---(0), 1384807_DSBC-100-80-PPVA-N3_right.dwg
    DWG2D, 1384807 DSBC-100-80-PPVA-N3---(0), 1384807_DSBC-100-80-PPVA-N3_left.dwg
    DWG2D, 1384807 DSBC-100-80-PPVA-N3---(0), 1384807_DSBC-100-80-PPVA-N3_top.dwg
    DWG2D, 1384807 DSBC-100-80-PPVA-N3---(0), 1384807_DSBC-100-80-PPVA-N3_bottom.dwg
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    

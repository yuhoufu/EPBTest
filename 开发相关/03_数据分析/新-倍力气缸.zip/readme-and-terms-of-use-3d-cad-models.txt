
EN   Your CAD data on 27.08.2025 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 191111 DNCT-100-75-PPV-A 
    
    DWG2D, 191111 DNCT-100-75-PPV-A---(asm_0), 191111_DNCT-100-75-PPV-A_front.dwg
    DWG2D, 191111 DNCT-100-75-PPV-A---(asm_0), 191111_DNCT-100-75-PPV-A_back.dwg
    DWG2D, 191111 DNCT-100-75-PPV-A---(asm_0), 191111_DNCT-100-75-PPV-A_right.dwg
    DWG2D, 191111 DNCT-100-75-PPV-A---(asm_0), 191111_DNCT-100-75-PPV-A_left.dwg
    DWG2D, 191111 DNCT-100-75-PPV-A---(asm_0), 191111_DNCT-100-75-PPV-A_top.dwg
    DWG2D, 191111 DNCT-100-75-PPV-A---(asm_0), 191111_DNCT-100-75-PPV-A_bottom.dwg
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
